package com.example.webapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.webapp.model.Property;
import com.example.webapp.repository.PropertyRepository;

@Service
public class PropertyService {
	
	@Autowired
	PropertyRepository groceryRepository;
	
	public void saveGrocery(Property grocery) {
		
		groceryRepository.save(grocery);
		
	}
	
	public List<Property> getAllGrocery() {
		return groceryRepository.findAll();
	}
	
	public void deleteGrocery(int id) {
		
		groceryRepository.deleteById(id);
		
	}
	
	public Property getGrocery(int id) {
		return groceryRepository.getById(id);
		
	}
	
	

}
