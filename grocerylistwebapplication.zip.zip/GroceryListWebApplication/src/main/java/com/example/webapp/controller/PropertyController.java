package com.example.webapp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.webapp.model.Property;
import com.example.webapp.service.PropertyService;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;

@Controller
public class PropertyController {

	@Autowired
	PropertyService groceryService;

	@PostMapping("/saveGrocery")
	public String saveGrocery(Property grocery, Model m) {
		groceryService.saveGrocery(grocery);
		return "redirect:/displayGrocery";
	}
	

	@GetMapping("/displayGrocery")
	public String displayGrocery(Model m) {
		List<Property> grocery = groceryService.getAllGrocery();

		m.addAttribute("listGrocery", grocery);
		return "adminPannel";

	}

	@GetMapping("/deleteGrocery/{grocery_id}")
	public String deleteGrocery(@PathVariable int grocery_id) {
		groceryService.deleteGrocery(grocery_id);

		return "redirect:/displayGrocery";

	}

	@GetMapping("/getGrocery/{grocery_id}" )
	public String getUpdate(@PathVariable int grocery_id, Model m) {
		Property grocery = groceryService.getGrocery(grocery_id);
		System.out.println(grocery);
		m.addAttribute("grocery", grocery);
		return "updateProperty";
	}
	
	@GetMapping("/contactOwner/{username}/{grocery_id}")
	public String contact(@PathVariable String username, @PathVariable int grocery_id , Model m) {
		
		Property grocery = groceryService.getGrocery(grocery_id);
		m.addAttribute("grocery", grocery);
		m.addAttribute("username", username);
		
		return "Contact";
	}

	

}
