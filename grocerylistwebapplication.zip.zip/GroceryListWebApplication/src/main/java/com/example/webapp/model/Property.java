package com.example.webapp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Property {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int  grocery_id;
	private String grocery_type;
	private String grocery_desc;
	private String grocery_name;
	private String grocery_price;
	
	public Property() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Property(int grocery_id, String grocery_type, String grocery_desc, String grocery_name,
			String grocery_price) {
		super();
		this.grocery_id = grocery_id;
		this.grocery_type = grocery_type;
		this.grocery_desc = grocery_desc;
		this.grocery_name = grocery_name;
		this.grocery_price = grocery_price;
	}

	public int getGrocery_id() {
		return grocery_id;
	}

	public void setGrocery_id(int grocery_id) {
		this.grocery_id = grocery_id;
	}

	public String getGrocery_type() {
		return grocery_type;
	}

	public void setGrocery_type(String grocery_type) {
		this.grocery_type = grocery_type;
	}

	public String getGrocery_desc() {
		return grocery_desc;
	}

	public void setGrocery_desc(String grocery_desc) {
		this.grocery_desc = grocery_desc;
	}

	public String getGrocery_name() {
		return grocery_name;
	}

	public void setGrocery_name(String grocery_name) {
		this.grocery_name = grocery_name;
	}

	public String getGrocery_price() {
		return grocery_price;
	}

	public void setGrocery_price(String grocery_price) {
		this.grocery_price = grocery_price;
	}

	@Override
	public String toString() {
		return "Property [grocery_id=" + grocery_id + ", grocery_type=" + grocery_type + ", grocery_desc="
				+ grocery_desc + ", grocery_name=" + grocery_name + ", grocery_price=" + grocery_price + "]";
	}
	
	
	
}
